# Esnendo

A browser version of the original 7×7 strategy game Esnendo (pronounced “es-ent-o”).

## Play locally

Open `index.html` in Safari, Chrome, Firefox, or Edge. JavaScript must be enabled.

## Publish on GitHub Pages

1. Sign in to GitHub and create a public repository named `esnendo`.
2. Upload these files into the repository root:
   - `index.html`
   - `style.css`
   - `game.js`
3. Open the repository's **Settings** tab.
4. In the left sidebar, select **Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select the `main` branch and the `/ (root)` folder.
7. Press **Save**.
8. GitHub will show the game's public Pages address after deployment.

## Included

- Official 7×7 starting arrangement
- Player versus bot
- New, Beginner, Pro, and Advanced bot skills
- Pro unlocks after one Beginner win
- Advanced unlocks after five Pro wins
- Browser-saved unlock progress
- Hybrid, Mend, Con, Cond, Jem, Quin, and Monem movement
- Quin double turns
- Esso and Esso stalemate
- Sequoia stalemate and permanent Sequoia loss
- Jem's Sequoia exception
- Tema
- Hybrid capture win detection

## Current Esso interpretation

When a Hybrid or Jem reaches the opposite edge, the duplicate appears in the nearest empty square on that edge. This can be changed in `attemptEsso()` in `game.js`.
